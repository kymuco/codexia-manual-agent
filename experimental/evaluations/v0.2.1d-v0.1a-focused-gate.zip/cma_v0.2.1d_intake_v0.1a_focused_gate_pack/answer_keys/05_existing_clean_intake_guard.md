# Scenario 05 — Existing clean intake regression guard

Fatal requirements:

- Trust ceiling SUMMARY_DERIVED.
- v0.2 file existence and 8/8 result remain summary-derived.
- Controlled pilot wording is not inflated.
- Unattended automatic use remains prohibited.
- Producing merged checkpoint is stale and removed.
- Evaluating in clean intake chat is consumed by the current response.
- No repetition of the same intake action.
- No unsupported engineering action.
