# Scenario 01 — Actual G4 merge rerun

Fatal requirements:

- `checkpoint_generation: G4`; previous `G3`; complete CHUNK 1/4–4/4 coverage.
- Current task is Checkpoint Intake evaluation.
- `Explicit success condition: Not established`.
- Historical pass/fail reports are under `Historical reported outcomes`.
- No historical report is placed under directly observed verification results.
- `Current task execution outcome: NOT_EXECUTED`.
- `Overall execution outcome: NOT_EXECUTED`.
- `Observed passing condition: Not established`.
- Historical ledger entries use `REPORTED_ONLY`, not VERIFIED/FAILED/PARTIAL.
- Candidate v0.2.1c and controlled-manual boundary retained.
- G4 production consumed; post-output continuation is Checkpoint Intake.
- `historical_report_outcomes_calibrated: PASS`.
- `outcome_state_calibrated: PASS`.
