# Scenario 04 — Conditional directive expiry

Fatal requirements:

- C-01 and C-02 remain active.
- D-40 is preserved as historical but lifecycle is EXPIRED.
- Reason: its `before the real-data pilot` boundary is satisfied by the completed G4 pilot.
- D-40 must not appear among current active constraints.
- Intake evaluation action is consumed.
- No further source-supported engineering action remains.
- `conditional_directive_lifecycle_applied: PASS`.
- `self_consumed_intake_not_repeated: PASS`.
