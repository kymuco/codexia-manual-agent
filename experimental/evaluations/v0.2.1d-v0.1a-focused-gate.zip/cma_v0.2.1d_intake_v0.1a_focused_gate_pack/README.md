# Codexia v0.2.1d + Checkpoint Intake v0.1a — Focused Gate

This gate validates two narrow repairs:

1. historical-report outcome and ledger calibration;
2. self-consumption and conditional-directive expiry in Checkpoint Intake.

## Protocol

Use a separate clean model chat for every scenario.

### Summarizer scenarios 01–02

1. Paste `prompts/cma_context_summarizer_v0.2.1d.txt`.
2. Expect exactly `READY_FOR_SOURCE`.
3. Paste one file from `summarizer_scenarios/`.
4. Save the full unedited `# CHECKPOINT_SUMMARY`.

### Intake scenarios 03–05

1. Paste `prompts/cma_checkpoint_intake_v0.1a.txt`.
2. Expect exactly `READY_FOR_CHECKPOINT`.
3. Paste one file from `intake_scenarios/`.
4. Save the full unedited `# CHECKPOINT_INTAKE`.

Do not show `answer_keys` to the tested model.

## Gate

- 5/5 PASS;
- zero fatal errors;
- historical reports never become current observed outcomes;
- no passing condition without explicit success condition and qualifying evidence;
- intake evaluation consumes itself;
- phase-bounded directives expire when their boundary is demonstrably complete;
- unattended automatic continuation remains unauthorized.
