from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    checkpoint = args.checkpoint.read_text(encoding="utf-8").rstrip()

    message = (
        "BEGIN_CHECKPOINT\n"
        + checkpoint
        + "\nEND_CHECKPOINT\n\n"
        + "BEGIN_CURRENT_REQUEST\n"
        + "Evaluate this final G4 checkpoint through Checkpoint Intake v0.1a in this clean chat. "
          "Preserve the receiving trust ceiling, consume this evaluation action, classify "
          "conditional directives by lifecycle, and do not authorize unattended automatic continuation.\n"
        + "END_CURRENT_REQUEST\n"
    )

    args.output.write_text(message, encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
