# Actual G4 → Checkpoint Intake Paired Rerun

This pack reruns only the failed end-to-end boundary. G1–G3 do not need to be repeated.

## Stage 1 — Rebuild G4 with Summarizer v0.2.1d

1. Start a clean model chat.
2. Paste `prompts/cma_context_summarizer_v0.2.1d.txt`.
3. Expect exactly `READY_FOR_SOURCE`.
4. Paste `inputs/01_actual_G4_merge_message.txt`.
5. Save the full response as `checkpoint_G4_v0.2.1d.txt`.

Required outcome:

- G4/G3 generation and complete coverage;
- historical outcomes marked reported-only;
- current Intake task `NOT_EXECUTED`;
- no observed passing condition;
- G4 production consumed;
- only Checkpoint Intake remains.

## Stage 2 — Evaluate new G4 with Intake v0.1a

Build the message:

```powershell
python tools\build_intake_message.py `
  --checkpoint checkpoint_G4_v0.2.1d.txt `
  --output intake_message_v0.1a.txt
```

1. Start another clean chat.
2. Paste `prompts/cma_checkpoint_intake_v0.1a.txt`.
3. Expect exactly `READY_FOR_CHECKPOINT`.
4. Paste `intake_message_v0.1a.txt`.
5. Save the full `# CHECKPOINT_INTAKE`.

Required outcome:

- receiving trust ceiling SUMMARY_DERIVED;
- incoming provenance ceiling shown separately;
- historical reports not independently verified;
- D-40 classified EXPIRED, not active;
- current intake action consumed;
- no recommendation to repeat intake;
- no unattended automatic continuation.

## Gate

Both stages PASS with zero fatal errors.
