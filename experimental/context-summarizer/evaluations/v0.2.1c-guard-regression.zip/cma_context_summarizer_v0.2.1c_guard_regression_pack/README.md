# Codexia Context Summarizer v0.2.1c — Guard Regression Pack

Validates nested claim provenance and aggregate-versus-itemized count reconciliation.

## Protocol

Use a separate clean model chat per scenario:

1. Paste `prompts/cma_context_summarizer_v0.2.1c.txt`.
2. Expect exactly `READY_FOR_SOURCE`.
3. Paste one scenario.
4. Save the complete unedited `# CHECKPOINT_SUMMARY`.
5. Close the chat.

Do not show `answer_keys` to the tested model.

## Order

1. `01_auth_aggregate_itemized_conflict.txt`
2. `02_prior_summary_raw_conflict.txt`
3. `03_three_generation_provenance.txt`
4. `04_renderer_confirmation_guard.txt`

## Gate

- 4/4 PASS;
- zero fatal errors;
- count conflict preserved;
- nested prior-derived claim provenance retained;
- no regression in outcome, confirmation, continuation, or input-mode calibration.
