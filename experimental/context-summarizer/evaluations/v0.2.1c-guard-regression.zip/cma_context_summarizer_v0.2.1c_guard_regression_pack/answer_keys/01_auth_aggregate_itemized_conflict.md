# Guard 01 — Aggregate/itemized conflict

Fatal requirements:

- Metadata `count_reconciliation: CONFLICT_UNRESOLVED`.
- Aggregate summary: 29 passed, 1 failed, 1 xfailed, 2 warnings.
- Itemized count:
  - 28 PASS
  - 1 FAIL
  - 1 XFAIL
  - 30 itemized test records total.
- Exact conflict:
  - aggregate total 31;
  - itemized total 30.
- Preserve both representations and mark unresolved conflict.
- Overall execution remains FAILED.
- `conflicts_preserved: PASS`.
- `zero_loss_fields_preserved: PASS`.
- `aggregate_itemized_counts_reconciled: PASS`.
- No cause invented.
