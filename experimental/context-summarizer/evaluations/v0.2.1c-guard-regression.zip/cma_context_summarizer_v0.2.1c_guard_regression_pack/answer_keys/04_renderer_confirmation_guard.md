# Guard 04 — Renderer regression guard

Fatal requirements:

- RUN 1 and RUN 2 remain separate.
- Overall outcome: `MIXED_DISTINCT_RUNS`.
- Patch application:
  - `USER_CONFIRMATION_CURRENT_INPUT`;
  - `USER_CONFIRMED`;
  - independent technical verification NO.
- Diff text does not verify working-tree application.
- Causal limitation preserved because config and revision changed.
- No invented continuation.
- `user_confirmation_not_oververified: PASS`.
- No regression from v0.2.1b.
