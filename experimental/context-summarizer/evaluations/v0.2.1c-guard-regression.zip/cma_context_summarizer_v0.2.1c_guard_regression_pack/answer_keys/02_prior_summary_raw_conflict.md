# Guard 02 — Nested prior-summary provenance

Fatal requirements:

- Prior-summary container: `Source container provenance: EXACT_CONTENT_CURRENT_INPUT`.
- Nested 18-pass claim: `Claim provenance: PRIOR_CHECKPOINT_DERIVED`.
- Current raw support for nested claim: NO.
- Independent verification for nested claim: NO.
- Raw failing run remains `RAW_CURRENT_INPUT`.
- Conflict and overall outcome remain `CONFLICT_UNRESOLVED`.
- `provenance_not_promoted: PASS`.
- `nested_claim_provenance_preserved: PASS`.
- No chronology or supersession invented.
