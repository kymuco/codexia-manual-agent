# Guard 03 — Three-generation provenance

Fatal requirements:

- Generation G3 from G2.
- Historical 18-pass claim remains `Claim provenance: PRIOR_CHECKPOINT_DERIVED`.
- Current note/container may be `EXACT_CONTENT_CURRENT_INPUT`.
- Current raw support: NO.
- Independent verification: NO.
- Repetition does not increase trust.
- `provenance_not_promoted: PASS`.
- `nested_claim_provenance_preserved: PASS`.
