# v0.2.1a Provenance Rerun Pack

Rerun only scenarios 01, 03, and 04 after the narrow current-source-type repair.

Gate:

- 3/3 PASS
- zero fatal errors
- no ordinary prose labeled RAW_CURRENT_INPUT
- `current_source_type_calibrated: PASS`
