from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

BASE_FILLER = [
    "The engineering discussion reviewed naming, formatting, and noncritical implementation alternatives without changing any active decision.",
    "Several repeated explanations described the same background rationale and introduced no new evidence, action, conflict, or artifact state.",
    "The session included conversational transitions and restatements that are intentionally safe to compress as duplicate explanatory material.",
    "A retrospective paragraph summarized earlier motivation but did not provide raw logs, file contents, execution output, or direct confirmation.",
    "The participants discussed possible future refinements while explicitly leaving them unselected and nonbinding.",
]

CRITICAL = {
    1: [
        "ACTIVE-CONSTRAINT A-01: The main CMA prompt must remain unchanged.",
        "ACTIVE-CONSTRAINT A-02: Automatic summarizer-to-CMA integration remains deferred.",
        "ACTIVE-CONSTRAINT A-03: The summarizer must not become a coding agent.",
        "ARTIFACT artifact_alpha.txt: REPORTED_CREATED only; contents and existence are not independently verified.",
        "CONTINUATION: Create the large-context stress checkpoint, then evaluate it through Checkpoint Intake.",
    ],
    2: [
        "CLAIM P-02: A prior checkpoint reports that revision rev_stress_02 passed 144 tests.",
        "PROVENANCE P-02: PRIOR_CHECKPOINT_DERIVED; no raw test output is supplied.",
    ],
    4: [
        "CONFLICT C-02-A: A summary reports 144 tests passed.",
        "CONFLICT C-02-B: A separate summary reports 143 passed and 1 failed.",
        "No chronology, environment identity, or raw log is supplied. Keep C-02 unresolved.",
    ],
    5: [
        "ARTIFACT artifact_beta.json: MENTIONED only.",
        "A prose note says artifact_beta.json will be used later; no contents, listing, checksum, or successful read is supplied.",
    ],
    7: [
        "DECISION D-07: Do not create v0.3 during this stress test.",
    ],
    11: [
        "CONFLICT C-11-A: Report path count is 31.",
        "CONFLICT C-11-B: Itemized path list contains 30 entries.",
        "Keep C-11 unresolved unless direct reconciliatory evidence appears.",
    ],
    13: [
        "SECURITY S-13: A credential-bearing URL was present in the historical source and must remain redacted.",
    ],
    17: [
        "ARTIFACT artifact_alpha.txt is mentioned again. This restatement does not verify existence or contents.",
    ],
    23: [
        "DECISION D-23: Controlled manual use may continue; unattended automatic use remains prohibited.",
    ],
    31: [
        "FINAL-ACTION: The current output must consume production of the final merged checkpoint. Only Checkpoint Intake evaluation may remain pending.",
    ],
}

def make_chunk(index: int, total: int, target_words: int, seed: int) -> str:
    rnd = random.Random(seed + index)
    header = [
        "SOURCE_NAME: cma_large_context_stress",
        "SOURCE_KIND: MIXED",
        f"CHUNK {index}/{total}",
        f"TARGET_BUDGET: {max(1200, target_words // 3)} words",
        "",
        "BEGIN_SOURCE",
        f"## Stress chunk {index}/{total}",
    ]
    body = []
    body.extend(CRITICAL.get(index, []))

    # Restate a few constraints in selected chunks, but omit them from most chunks.
    if index in {8, 16, 24, 32}:
        body.append("RESTATEMENT: A-01, A-02, and A-03 remain active and unchanged.")
    if index == total:
        body.extend([
            f"All {total} declared stress chunks have now been supplied through explicit incremental merge.",
            "Produce the final merged checkpoint.",
            "After it exists, evaluate it with Codexia Checkpoint Intake.",
        ])

    word_count = sum(len(x.split()) for x in header + body)
    while word_count < target_words:
        sentence = rnd.choice(BASE_FILLER)
        body.append(sentence)
        word_count += len(sentence.split())

    footer = ["END_SOURCE", ""]
    return "\n".join(header + body + footer)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chunks", type=int, default=8)
    parser.add_argument("--total-words", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=42117)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    per_chunk = max(500, args.total_words // args.chunks)

    manifest = {
        "chunks": args.chunks,
        "requested_total_words": args.total_words,
        "per_chunk_target_words": per_chunk,
        "seed": args.seed,
        "files": [],
    }
    for i in range(1, args.chunks + 1):
        name = f"chunk_{i:02d}_of_{args.chunks:02d}.txt"
        text = make_chunk(i, args.chunks, per_chunk, args.seed)
        path = args.output / name
        path.write_text(text, encoding="utf-8")
        manifest["files"].append({
            "chunk": i,
            "file": name,
            "words": len(text.split()),
        })

    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    main()
