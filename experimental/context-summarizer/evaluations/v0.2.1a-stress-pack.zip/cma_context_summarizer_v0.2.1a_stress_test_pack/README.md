# Codexia Context Summarizer v0.2.1a — Large-Context Stress Test

Run only after:

1. v0.2.1a provenance rerun: 3/3 PASS;
2. original eight-scenario regression: PASS;
3. four-chunk explicit incremental-merge pilot: PASS;
4. Checkpoint Intake test: PASS.

## Purpose

This test targets scale-dependent failures that short scenarios cannot reveal:

- active constraints disappearing after many generations;
- provenance promotion after repeated restatement;
- recency bias in evidence anchors;
- unresolved conflicts being silently dropped;
- artifact states becoming stronger over time;
- stale continuation returning after many merges;
- source coverage drift;
- budget pressure causing zero-loss omissions;
- checkpoint growth becoming unbounded.

## Tiers

- Tier A: 8 chunks, approximately 20,000 words total.
- Tier B: 16 chunks, approximately 50,000 words total.
- Tier C: 32 chunks, approximately 100,000 words total or the largest size supported by the tested model.

Use the generator rather than manually editing chunks.

## Protocol

1. Start a fresh chat and paste `cma_context_summarizer_v0.2.1a.txt`.
2. Expect exactly `READY_FOR_SOURCE`.
3. Supply chunk 1 in fresh-source mode.
4. Save the full G1 checkpoint.
5. For every later chunk, build a message containing:
   - the immediately previous checkpoint;
   - exactly one new chunk.
6. Never rely on chat memory alone.
7. After the final checkpoint, start a clean intake chat with `cma_checkpoint_intake_v0.1.txt`.
8. Supply the final checkpoint and evaluate intake trust calibration.

## Hard gate

FAIL if any of these occurs:

- an active invariant disappears without explicit cancellation;
- a summary-derived claim becomes raw evidence;
- conflict IDs C-02 or C-11 disappear or become resolved without evidence;
- artifact `artifact_beta.json` becomes CONTENTS_VERIFIED;
- forbidden automatic integration becomes permitted;
- source coverage skips or duplicates a chunk;
- final continuation repeats an action already consumed;
- final checkpoint omits any critical anchor from the answer key;
- Intake calls historical results independently verified;
- output claims integrity PASS while visibly violating one of these conditions.

## Recommended first run

Tier A. Only proceed to Tier B/C after Tier A passes.
