# Codexia Context Summarizer v0.2.1b — Focused Regression Pack

This pack validates the v0.2.1b repair.

## Run order

Run scenarios 02 through 08, each in a fresh model chat:

1. Paste `prompts/cma_context_summarizer_v0.2.1b.txt`.
2. Expect exactly `READY_FOR_SOURCE`.
3. Paste one file from `scenarios/`.
4. Save the complete unedited `# CHECKPOINT_SUMMARY`.
5. Close the chat before the next scenario.

Do not show the model files from `answer_keys/`.

## Gate

Required:

- 7/7 scenario PASS;
- zero fatal errors;
- no failed, partial, mixed, or conflicted run represented as an observed passing condition;
- no user confirmation represented as independent technical verification without corroboration;
- no blocker converted into an unselected next action;
- correct fresh-source versus incremental-merge field calibration.

## Key fields introduced by v0.2.1b

- `source_gap_present`
- `missing_source_ranges`
- `Observed verification results`
- `Observed passed subchecks`
- `Observed failing condition`
- `Overall execution outcome`
- ledger result `USER_CONFIRMED`
- `outcome_state_calibrated`
- `user_confirmation_not_oververified`
- `continuation_source_selection_preserved`
- `input_mode_fields_calibrated`
