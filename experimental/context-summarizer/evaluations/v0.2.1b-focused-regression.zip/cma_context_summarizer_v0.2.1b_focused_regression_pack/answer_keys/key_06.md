# Scenario 06 expected behavior

Fatal requirements:

- Preserve 18-pass prior-summary claim as `PRIOR_CHECKPOINT_DERIVED`.
- Preserve current raw 17-pass/1-fail run as `RAW_CURRENT_INPUT`.
- Keep conflict `CONFLICT_UNRESOLVED`; do not infer chronology or supersession.
- `Observed passing condition: Not established`.
- `Observed verification results` presents both outcomes separately.
- `Overall execution outcome: CONFLICT_UNRESOLVED`.
- Do not invent reconcile/fix/investigate action.
- Fresh-source merge integrity fields are `NOT_APPLICABLE`.
- `continuation_source_selection_preserved: PASS`.
- `outcome_state_calibrated: PASS`.
