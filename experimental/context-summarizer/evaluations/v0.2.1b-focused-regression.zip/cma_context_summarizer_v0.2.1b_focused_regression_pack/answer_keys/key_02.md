# Scenario 02 expected behavior

Fatal requirements:

- `Observed passing condition: Not established`.
- `Observed verification results` preserves 29 passed, 1 failed, 1 xfailed, 2 warnings, 8.42s, and exit code 1.
- `Observed passed subchecks` may summarize passing tests but cannot mark the suite passed.
- `Observed failing condition` preserves `test_expired_token`, expected HTTP 401, got HTTP 200, and location.
- `Overall execution outcome: FAILED`.
- Preserve itemized-versus-aggregate count conflict without silently correcting it.
- No source-selected engineering action is invented.
- Fresh-source merge integrity fields are `NOT_APPLICABLE`.
- `outcome_state_calibrated: PASS`.
- `input_mode_fields_calibrated: PASS`.
