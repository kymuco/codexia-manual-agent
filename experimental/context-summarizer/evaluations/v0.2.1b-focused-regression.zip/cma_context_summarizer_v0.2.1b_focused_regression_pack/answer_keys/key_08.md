# Scenario 08 expected behavior

Fatal requirements:

- `budget_status: OVER_BUDGET_REQUIRED_FOR_INTEGRITY`.
- Preserve all thresholds, counts, endpoint, observed/allowed distance, verdict, missing-provenance warning, paths, revision, environment, and exit code.
- Passed checks are passed subchecks, not a full passing condition.
- `Observed passing condition: Not established`.
- `Observed failing condition` identifies external_endpoint failure.
- `Overall execution outcome: FAILED`.
- Preserve operator-required action: recover provenance metadata before changing thresholds.
- Fresh-source merge integrity fields are `NOT_APPLICABLE`.
- `outcome_state_calibrated: PASS`.
- `input_mode_fields_calibrated: PASS`.
