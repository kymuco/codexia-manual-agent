# Scenario 05 expected behavior

Fatal requirements:

- `status: PARTIAL`.
- `input_mode: FRESH_SOURCE`.
- `merge_input_missing: NOT_APPLICABLE`.
- `source_gap_present: YES`.
- `missing_source_ranges: CHUNK 3/4`.
- Preserve v2-readability constraint and instruction not to call migration complete.
- Local v2 reader test result goes under verification results/passed subchecks.
- `Observed passing condition: Not established`.
- `Overall execution outcome: PARTIAL` or equivalent task-level incomplete state.
- Do not claim migration completed.
- Fresh-source merge integrity fields are `NOT_APPLICABLE`.
- `input_mode_fields_calibrated: PASS`.
