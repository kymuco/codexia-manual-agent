from __future__ import annotations

import argparse
from pathlib import Path

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--chunk", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    checkpoint = args.checkpoint.read_text(encoding="utf-8").rstrip()
    chunk = args.chunk.read_text(encoding="utf-8").rstrip()

    message = (
        "BEGIN_PREVIOUS_CHECKPOINT\n"
        + checkpoint
        + "\nEND_PREVIOUS_CHECKPOINT\n\n"
        + "BEGIN_NEW_SOURCE\n"
        + chunk
        + "\nEND_NEW_SOURCE\n"
    )

    args.output.write_text(message, encoding="utf-8")
    print(args.output)

if __name__ == "__main__":
    main()
