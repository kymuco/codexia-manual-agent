# Codexia Context Summarizer v0.2.1c — Four-Chunk Real-Data Pilot

This pilot uses the actual project history from v0.1 through v0.2.1c.

## Important

Use one summarizer chat for G1 through G4, but never rely on chat memory alone.

Every merge after CHUNK 1 must explicitly include:

- the immediately previous checkpoint;
- exactly one new chunk.

## Step 1 — G1

1. Start a clean Gemini chat.
2. Paste `prompts/cma_context_summarizer_v0.2.1c.txt`.
3. Expect exactly `READY_FOR_SOURCE`.
4. Paste `chunks/chunk_01_of_04.txt`.
5. Save the full response as `checkpoint_G1.txt`.

## Step 2 — G2

Build the input:

```powershell
python tools\build_merge_message.py `
  --checkpoint checkpoint_G1.txt `
  --chunk chunks\chunk_02_of_04.txt `
  --output message_G2.txt
```

Paste `message_G2.txt` into the same summarizer chat.

Save the response as `checkpoint_G2.txt`.

## Step 3 — G3

```powershell
python tools\build_merge_message.py `
  --checkpoint checkpoint_G2.txt `
  --chunk chunks\chunk_03_of_04.txt `
  --output message_G3.txt
```

Save the response as `checkpoint_G3.txt`.

## Step 4 — G4

```powershell
python tools\build_merge_message.py `
  --checkpoint checkpoint_G3.txt `
  --chunk chunks\chunk_04_of_04.txt `
  --output message_G4.txt
```

Save the response as `checkpoint_G4_final.txt`.

## Step 5 — Clean Checkpoint Intake

1. Start a new clean chat.
2. Paste `prompts/cma_checkpoint_intake_v0.1.txt`.
3. Expect exactly `READY_FOR_CHECKPOINT`.
4. Build the intake message:

```powershell
python tools\build_intake_message.py `
  --checkpoint checkpoint_G4_final.txt `
  --output intake_message.txt
```

5. Paste `intake_message.txt`.
6. Save the full `# CHECKPOINT_INTAKE` response.

## Send back for evaluation

Send:

- checkpoint G1;
- checkpoint G2;
- checkpoint G3;
- checkpoint G4;
- final Checkpoint Intake response.

You may send them one at a time.

Do not show `answer_keys` to the tested model.
