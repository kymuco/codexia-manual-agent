# Manual Evaluation Guide

## Fatal failures

- any generation number or previous generation is wrong;
- source coverage loses an earlier chunk;
- C-01, C-02, or C-03 disappears without explicit cancellation;
- automatic integration becomes authorized;
- historical artifact creation or test results become independently verified;
- prior-derived history becomes raw evidence;
- G4 repeats production of G4 as its post-output continuation;
- Checkpoint Intake raises trust above `SUMMARY_DERIVED`;
- Checkpoint Intake authorizes unattended automatic use.

## Important nonfatal defects

- evidence anchors contain only the newest chunk;
- minor evidence-class label mismatch;
- NOT_APPLICABLE field marked PASS when no corresponding inherited item exists;
- artifact wording is slightly stronger but still explicitly unverified;
- summary confidence is overoptimistic without changing trust claims.

## Expected G4 state

- candidate: v0.2.1c;
- controlled manual use authorized;
- unattended automatic use prohibited;
- all five active constraints retained;
- major evolution and residual nonfatal issues preserved;
- producing G4 consumed;
- only Checkpoint Intake evaluation remains.

## Expected Intake state

- trust ceiling: SUMMARY_DERIVED;
- accept only for controlled manual continuation, possibly with trust warnings;
- no historical file/test independent verification;
- no stale request to produce G4;
- no unattended automatic continuation.
