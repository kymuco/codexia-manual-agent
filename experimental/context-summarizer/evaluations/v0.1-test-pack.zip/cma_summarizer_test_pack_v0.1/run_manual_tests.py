#!/usr/bin/env python3
"""Manual test helper for Codexia Context Summarizer.

No API is required. The script prints test material for pasting into a chat
and performs a lightweight structural check on saved model output.
Semantic grading still requires the answer key or evaluator prompt.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST_PATH = ROOT / "manifest.json"


def load_manifest() -> dict:
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def get_case(case_id: str) -> dict:
    manifest = load_manifest()
    for case in manifest["scenarios"]:
        if case["id"] == case_id.zfill(2):
            return case
    raise SystemExit(f"Unknown scenario: {case_id}")


def scenario_path(case_id: str) -> Path:
    return ROOT / "scenarios" / f"scenario_{case_id.zfill(2)}.txt"


def key_path(case_id: str) -> Path:
    return ROOT / "answer_keys" / f"key_{case_id.zfill(2)}.md"


def list_cases() -> None:
    for case in load_manifest()["scenarios"]:
        print(f'{case["id"]}: {case["name"]}')


def show_case(case_id: str, combined: bool) -> None:
    case_id = case_id.zfill(2)
    scenario = scenario_path(case_id).read_text(encoding="utf-8")
    if combined:
        prompt = (ROOT / "prompts" / "cma_context_summarizer_v0.1.txt").read_text(
            encoding="utf-8"
        )
        print("===== FIRST MESSAGE: SUMMARIZER PROMPT =====")
        print(prompt.rstrip())
        print("\n===== SECOND MESSAGE: TEST SCENARIO =====")
    print(scenario.rstrip())


def show_key(case_id: str) -> None:
    print(key_path(case_id).read_text(encoding="utf-8").rstrip())


def score_case(case_id: str, output_path: Path) -> int:
    case = get_case(case_id)
    if not output_path.exists():
        raise SystemExit(f"Output file does not exist: {output_path}")

    text = output_path.read_text(encoding="utf-8")
    required = case.get("required_literals", [])
    forbidden = case.get("forbidden_literals", [])

    passed = 0
    total = len(required) + len(forbidden)

    print(f'Scenario {case["id"]}: {case["name"]}')
    print("\nRequired evidence markers:")
    for literal in required:
        ok = literal.casefold() in text.casefold()
        passed += int(ok)
        print(f'  [{"PASS" if ok else "MISS"}] {literal}')

    print("\nForbidden leakage markers:")
    for literal in forbidden:
        ok = literal not in text
        passed += int(ok)
        print(f'  [{"PASS" if ok else "LEAK"}] {literal}')

    percentage = 100.0 if total == 0 else (passed / total * 100)
    print(f"\nStructural score: {passed}/{total} ({percentage:.1f}%)")
    print("This is not a semantic verdict. Review the hidden answer key for fatal errors.")

    if any(literal in text for literal in forbidden):
        return 2
    if percentage < 70:
        return 1
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list", help="List scenarios")

    show = sub.add_parser("show", help="Print a scenario")
    show.add_argument("id")
    show.add_argument(
        "--combined",
        action="store_true",
        help="Print the summarizer prompt before the scenario",
    )

    key = sub.add_parser("key", help="Print the hidden answer key")
    key.add_argument("id")

    score = sub.add_parser("score", help="Run lightweight structural checks")
    score.add_argument("id")
    score.add_argument("output", type=Path)

    args = parser.parse_args()

    if args.command == "list":
        list_cases()
        return 0
    if args.command == "show":
        show_case(args.id, args.combined)
        return 0
    if args.command == "key":
        show_key(args.id)
        return 0
    if args.command == "score":
        return score_case(args.id, args.output)

    return 2


if __name__ == "__main__":
    sys.exit(main())
