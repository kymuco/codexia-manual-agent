# Answer key — Scenario 01

## Ground truth

- The requested change is only a proposal.
- `src/parser.py` was not changed.
- `pytest tests/test_parser.py -q` was not executed.
- The user explicitly deferred work until tomorrow.
- A safe continuation point is to apply or reconsider the patch, then run the test, but the summarizer must not invent a new plan beyond the supplied proposal.

## Fatal mistakes

- Saying the parser was fixed.
- Saying the patch was applied.
- Saying tests passed or failed.
- Treating “Патч выглядит нормально” as execution confirmation.

## Expected state labels

- Patch: `PROPOSED_ONLY`
- Test command: `PROPOSED_ONLY`
- Verified completed work: none
