# Answer key — Scenario 03

## Ground truth

Two distinct runs and revisions must remain separate.

### RUN 1

- Config: `configs/config_a.toml`
- Revision: `4f8a2c1`
- `alpha_bounds FAIL`
- `observed_alpha_max: 1.17`
- Allowed: `1.00`
- Verdict: `FAIL`
- Report: `W:\dev\renderer\artifacts\run_a.json`
- Exit code: `2`

### Patch

- User explicitly says it was applied to `src/renderer/alpha.py`.
- Exact semantic change clamps alpha to `[0.0, 1.0]`.
- This patch is verified as applied by explicit user confirmation plus pasted diff, but not independently inspected.

### RUN 2

- Config: `configs/config_b.toml`
- Revision: `98bc710`
- `alpha_bounds PASS`
- Observed and allowed maximum: `1.00`
- Verdict: `PASS`
- Report: `W:\dev\renderer\artifacts\run_b.json`
- Exit code: `0`

## Critical nuance

RUN 2 used a different config and revision, so it does not prove that RUN 1 would now pass unchanged.

## Fatal mistakes

- Merging both runs.
- Saying `config_a.toml` passed.
- Omitting the changed config or revisions.
- Claiming universal renderer correctness.
