from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("scenario", choices=[f"{i:02d}" for i in range(1, 6)])
    parser.add_argument("--answer-key", action="store_true")
    args = parser.parse_args()

    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    item = next(x for x in manifest["scenarios"] if x["id"] == args.scenario)
    target = item["answer_key"] if args.answer_key else item["file"]
    print((ROOT / target).read_text(encoding="utf-8"))

if __name__ == "__main__":
    main()
