# Codexia Context Summarizer v0.2.1 Targeted Test Pack

This pack tests the repair targets discovered during the first real-data pilot:

1. active constraint retention across explicit incremental merge;
2. provenance preservation across three summary generations;
3. artifact-state inheritance without promotion;
4. continuation actions consumed by producing the current checkpoint;
5. safe intake into a clean CMA chat.

## Files

- `prompts/cma_context_summarizer_v0.2.1.txt`
- `prompts/cma_checkpoint_intake_v0.1.txt`
- `prompts/manual_test_wrapper.txt`
- `prompts/evaluator_prompt.txt`
- `scenarios/01_...` through `05_...`
- matching hidden `answer_keys/`
- `manifest.json`
- `scorecard.csv`

## Gate

All five targeted scenarios must pass without a fatal error before rerunning the original eight-scenario regression.
